# Random Team Generator

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)

Random Team Generator with Vanilla Javascript & Bootstrap 5.

## Features

- Randomize member each team

## Author

- [Ryu Kurnianto](https://github.com/ryuuwiz)

## License

This project is open source and available under the [MIT License](LICENSE.md).
